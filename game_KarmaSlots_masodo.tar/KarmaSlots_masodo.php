<?php
/*--------------------------------------------------*/
/* File Created by PracticalLightning Arcade 1.0!	    */
/* File Generated:     2020-01-03 09:01:03                             */
/*--------------------------------------------------*/

$config = array(
	'active'			=> '1',
	'bgcolor'			=> '000000',
	'gcat'			=> '1',
	'gheight'			=> '250',
	'gkeys'			=> '',
	'gname'			=> 'KarmaSlots_masodo',
	'gtitle'			=> 'Karma Slots',
	'gwidth'			=> '300',
	'gwords'			=> 'A basic little slots game with a `Reddit` theme.',
	'highscore_type'			=> 'high',
	'object'			=> 'A basic little slots game with a `Reddit` theme.',
	'snggame'			=> '0',
);
?>